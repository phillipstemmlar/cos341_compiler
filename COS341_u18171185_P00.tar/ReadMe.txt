==================================JAR FILE==========================================
To compile the code into a JAR file, use

	make jar

The JAR file will be available in the bin/ directory.

To run the JAR file, called COS341_u18171185_P00.jar, use

	java -jar COS341_u18171185_P00.jar <inputfile> <outputfile>




==================================JAVA FILE=========================================

To compile the code into Java Class files, use

	make

The Java Class files will be available in this directory.

The Main Java Class is the Lexer Class. To run it, use

	java Lexer <inputfile> <outputfile>



===================================DEVELOPMENT ENVIRONMENT===========================

openjdk 11.0.7 2020-04-14
OpenJDK Runtime Environment (build 11.0.7+10-post-Ubuntu-2ubuntu218.04)
OpenJDK 64-Bit Server VM (build 11.0.7+10-post-Ubuntu-2ubuntu218.04, mixed mode, sharing)
