public class NormalDFAState extends DFAstate{

	public NormalDFAState( String name){
		super(false, name);
	}

};